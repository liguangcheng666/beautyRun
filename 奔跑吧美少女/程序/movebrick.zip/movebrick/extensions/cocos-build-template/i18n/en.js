module.exports = {
    title: 'Cocos Build Plugin Example',
    ruleTest_msg: 'Verify that the field complies with the rules',
    options: {
        enterCocos: 'Please Enter cocos ',
        remoteAddress: 'remoteAddress',
    },
    description: 'A single example about Cocos Build Plugin',
};
