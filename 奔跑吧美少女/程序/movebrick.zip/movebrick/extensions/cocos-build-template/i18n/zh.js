module.exports = {
    title: '构建插件示例',
    ruleTest_msg: '验证该字段符合规则',
    options: {
        enterCocos: `请输入 'cocos' 字符 `,
        remoteAddress: '资源服务地址',
    },
    description: '构建插件的一个简单示例',
};
