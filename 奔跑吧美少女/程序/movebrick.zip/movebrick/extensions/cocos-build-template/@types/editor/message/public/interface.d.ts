export interface MessageInfo {
    methods: string[];
    public?: boolean;
    description?: string;
    doc?: string;
    sync?: boolean;
}
