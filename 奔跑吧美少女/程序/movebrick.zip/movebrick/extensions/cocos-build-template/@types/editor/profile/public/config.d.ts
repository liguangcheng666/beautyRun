export declare const VERSION: string;
