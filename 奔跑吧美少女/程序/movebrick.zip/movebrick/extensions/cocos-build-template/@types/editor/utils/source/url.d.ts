/**
 * 快捷获取文档路径
 * @param relativeUrl
 * @param type
 */
export declare function getDocUrl(relativeUrl: string, type?: 'manual' | 'api'): string;
